<div class="menu">
	<a href="home.php"><div class="drop">Inicio</div></a>
	<div class="drop">Cadastro
		<div class="drop_menu">
			<a href="un_producao.php"><div class="menu_drop">Unidade de Produção</div></a>
			<a href="fornecedor.php"><div class="menu_drop">Fornecedor</div></a>
			<a href="produto.php"><div class="menu_drop">Produto</div></a>
		</div>
	</div>
	<div class="drop">Lançamentos
		<div class="drop_menu">
			<a href="fornecedor_local.php"><div class="menu_drop">Fornecedor Local</div></a>
			<a href="fornecedor_externo.php"><div class="menu_drop">Fornecedor Externo</div></a>
		</div>
	</div>
	<div class="drop">Relatórios
		<div class="drop_menu">
			<a href="relatorio_fornecedor_local.php"><div class="menu_drop">Fornecedor Local</div></a>
			<a href="relatorio_fornecedor_externo.php"><div class="menu_drop">Fornecedor Externo</div></a>
			<a href="combustivel.php"><div class="menu_drop">FL - Combustível</div></a>
			<a href="relatorio_fornecedores.php" target="_blank"><div class="menu_drop">Fornecedores</div></a>
			<a href="projecao.php"><div class="menu_drop">Projeção</div></a>
		</div>
	</div>
</div>
<div class="corpo">