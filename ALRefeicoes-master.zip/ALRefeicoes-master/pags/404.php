<!DOCTYPE HTML>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <base href="<?php echo $_SERVER["SCRIPT_NAME"];?>"></base>
    <title></title>
    <link rel="stylesheet" type="text/css" href="../assets/css/404.css">
</head>
<body>
    <div id="container">
        <div id="lbl_404" class="inset-text">Erro 404</div>
        <div id="lbl">Oops! Faltou campos a serem preenchidos :(</div>
    </div>
</body>
</html>