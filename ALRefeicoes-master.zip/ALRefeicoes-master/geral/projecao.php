<?php
	include('../include/topo.php');
	include('../include/corpo.php');
?>

<?php
	include('../include/rodape.php');
?>